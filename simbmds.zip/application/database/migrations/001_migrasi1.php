<?php
class Migration_migrasi1 extends CI_Migration {

    public function up() {
    	
    }

    public function down() {

    }
}