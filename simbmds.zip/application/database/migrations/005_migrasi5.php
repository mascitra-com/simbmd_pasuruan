<?php
class Migration_migrasi5 extends CI_Migration {

    public function up() {
    	
    }

    public function down() {

    }
}