<?php
class Migration_migrasi11 extends CI_Migration {

    public function up() {

    }

    public function down() {

    }
}