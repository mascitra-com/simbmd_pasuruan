<?php
class Migration_migrasi3 extends CI_Migration {

    public function up() {
    	
    }

    public function down() {

    }
}