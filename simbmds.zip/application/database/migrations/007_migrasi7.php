<?php
class Migration_migrasi7 extends CI_Migration {

    public function up() {
    	
    }

    public function down() {

    }
}