<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Rekening_model extends MY_Model
{
	public $_table = 'rekening';

	public function __construct()
    {
        parent::__construct();
    }
}